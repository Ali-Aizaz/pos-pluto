export function handleGoogle() {
  console.log("google");
  router.push("/home");
}
